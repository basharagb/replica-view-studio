import React from 'react';

const TestPage = () => {
  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h1>Hello</h1>
      <p>This is a test page to verify routing is working correctly.</p>
    </div>
  );
};

export default TestPage;
