// Real Silo API Service for connecting to physical silo sensors
import { Strings } from '../utils/Strings';

// API Endpoint: {BASE_URL}/readings/avg/latest/by-silo-number

import { TemperatureColor } from '../types/silo';

// API Response interface matching the real API structure
export interface RealSiloApiResponse {
  silo_group: string;
  silo_number: number;
  cable_number: number | null;
  level_0: number | null;  // S1 sensor
  color_0: string;  // S1 color
  level_1: number | null;  // S2 sensor
  color_1: string;  // S2 color
  level_2: number | null;  // S3 sensor
  color_2: string;  // S3 color
  level_3: number | null;  // S4 sensor
  color_3: string;  // S4 color
  level_4: number | null;  // S5 sensor
  color_4: string;  // S5 color
  level_5: number | null;  // S6 sensor
  color_5: string;  // S6 color
  level_6: number | null;  // S7 sensor
  color_6: string;  // S7 color
  level_7: number | null;  // S8 sensor
  color_7: string;  // S8 color
  silo_color: string;
  timestamp: string;
}

// Processed silo data for internal use
export interface ProcessedSiloData {
  siloNumber: number;
  sensors: number[];  // [S1, S2, S3, S4, S5, S6, S7, S8]
  sensorColors: string[];  // Colors for each sensor
  siloColor: string;
  maxTemp: number;
  timestamp: Date;
  isLoaded: boolean;
}

// Default wheat color for unloaded silos
export const WHEAT_COLOR = '#93856b';

// API configuration
const API_BASE_URL = Strings.BASE_URL;
const API_ENDPOINT = '/readings/avg/latest/by-silo-number';

// Persistent storage key for silo data cache
const SILO_CACHE_STORAGE_KEY = 'replica-view-studio-silo-data-cache';

// Cache for storing fetched silo data with persistent storage
class SiloDataCache {
  private cache = new Map<number, ProcessedSiloData>();
  private loadingStates = new Map<number, boolean>();

  constructor() {
    // Load cached data from localStorage on initialization
    this.loadFromStorage();
  }

  // Load cached data from localStorage
  private loadFromStorage(): void {
    try {
      const stored = localStorage.getItem(SILO_CACHE_STORAGE_KEY);
      if (stored) {
        const data = JSON.parse(stored);
        // Convert stored data back to Map format
        Object.entries(data).forEach(([siloNum, siloData]: [string, ProcessedSiloData]) => {
          const processedData: ProcessedSiloData = {
            ...siloData,
            timestamp: new Date(siloData.timestamp) // Convert timestamp back to Date
          };
          this.cache.set(parseInt(siloNum), processedData);
        });
        console.log(`Loaded ${this.cache.size} silos from persistent storage`);
      }
    } catch (error) {
      console.warn('Failed to load silo cache from storage:', error);
    }
  }

  // Save cached data to localStorage
  private saveToStorage(): void {
    try {
      const dataToStore: Record<number, ProcessedSiloData> = {};
      this.cache.forEach((data, siloNum) => {
        // Only save loaded silos (not wheat-colored defaults)
        if (data.isLoaded) {
          dataToStore[siloNum] = data;
        }
      });
      localStorage.setItem(SILO_CACHE_STORAGE_KEY, JSON.stringify(dataToStore));
    } catch (error) {
      console.warn('Failed to save silo cache to storage:', error);
    }
  }

  // Check if silo data is cached
  has(siloNumber: number): boolean {
    return this.cache.has(siloNumber);
  }

  // Get cached silo data
  get(siloNumber: number): ProcessedSiloData | undefined {
    return this.cache.get(siloNumber);
  }

  // Set silo data in cache
  set(siloNumber: number, data: ProcessedSiloData): void {
    this.cache.set(siloNumber, data);
    this.loadingStates.set(siloNumber, false);
    
    // Save to persistent storage if this is loaded data
    if (data.isLoaded) {
      this.saveToStorage();
    }
  }

  // Check if silo is currently loading
  isLoading(siloNumber: number): boolean {
    return this.loadingStates.get(siloNumber) || false;
  }

  // Set loading state for silo
  setLoading(siloNumber: number, loading: boolean): void {
    this.loadingStates.set(siloNumber, loading);
  }

  // Get default wheat-colored silo data
  getDefaultSiloData(siloNumber: number): ProcessedSiloData {
    return {
      siloNumber,
      sensors: [0, 0, 0, 0, 0, 0, 0, 0],  // All sensors zero
      sensorColors: Array(8).fill(WHEAT_COLOR),
      siloColor: WHEAT_COLOR,
      maxTemp: 0,
      timestamp: new Date(),
      isLoaded: false
    };
  }

  // Clear specific silo from cache (including persistent storage)
  clearSilo(siloNumber: number): void {
    this.cache.delete(siloNumber);
    this.loadingStates.delete(siloNumber);
    // Update persistent storage
    this.saveToStorage();
    console.log(`Cleared silo ${siloNumber} from cache`);
  }

  // Clear all cached data (including persistent storage)
  clear(): void {
    this.cache.clear();
    this.loadingStates.clear();
    // Clear persistent storage
    try {
      localStorage.removeItem(SILO_CACHE_STORAGE_KEY);
      console.log('Cleared silo cache from persistent storage');
    } catch (error) {
      console.warn('Failed to clear silo cache from storage:', error);
    }
  }

  // Get all cached silo numbers
  getCachedSiloNumbers(): number[] {
    return Array.from(this.cache.keys());
  }
}

// Global cache instance
const siloCache = new SiloDataCache();

// Convert API response to processed silo data
const processApiResponse = (apiData: RealSiloApiResponse): ProcessedSiloData => {
  // Handle null values by converting them to 0
  let sensors = [
    apiData.level_0 ?? 0, apiData.level_1 ?? 0, apiData.level_2 ?? 0, apiData.level_3 ?? 0,
    apiData.level_4 ?? 0, apiData.level_5 ?? 0, apiData.level_6 ?? 0, apiData.level_7 ?? 0
  ];
  
  let sensorColors = [
    apiData.color_0, apiData.color_1, apiData.color_2, apiData.color_3,
    apiData.color_4, apiData.color_5, apiData.color_6, apiData.color_7
  ];

  // 🔧 TEMPORARY FIX: Silo 10 S8 sensor is disconnected - use S7 value instead
  // TODO: Remove this fix when hardware issue is resolved (see SILO_10_S8_SENSOR_FIX.md)
  if (apiData.silo_number === 10) {
    const s7Value = apiData.level_6 ?? 0;  // S7 is level_6 (0-indexed)
    const s7Color = apiData.color_6;
    
    // Only apply fix if S8 appears disconnected (null, 0, or gray color)
    const s8Value = apiData.level_7 ?? 0;
    const s8Color = apiData.color_7;
    const isS8Disconnected = s8Value === 0 || s8Value === null || 
                             s8Color === '#9ca3af' || s8Color === '#8c9494' || s8Color === '#6b7280';
    
    if (isS8Disconnected && s7Value > 0) {
      sensors[7] = s7Value;  // Set S8 (index 7) to S7 value
      sensorColors[7] = s7Color;  // Set S8 color to S7 color
      
      console.log(`🔧 [SILO 10 S8 FIX] Applied temporary fix: S8 (${s8Value}°C, ${s8Color}) -> S7 value (${s7Value}°C, ${s7Color})`);
    }
  }
  
  // Filter out null/zero values when calculating max temperature
  const validTemperatures = sensors.filter(temp => temp !== null && temp > 0);
  const maxTemp = validTemperatures.length > 0 ? Math.max(...validTemperatures) : 0;
  
  // 🔍 COMPREHENSIVE DEBUG LOGGING FOR LIVE READINGS
  console.log(`🔍 [LIVE READINGS DEBUG] Silo ${apiData.silo_number} API Response:`, {
    endpoint: '/readings/avg/latest/by-silo-number',
    siloGroup: apiData.silo_group,
    cableNumber: apiData.cable_number,
    sensors: {
      S1: `${apiData.level_0}°C (${apiData.color_0})`,
      S2: `${apiData.level_1}°C (${apiData.color_1})`,
      S3: `${apiData.level_2}°C (${apiData.color_2})`,
      S4: `${apiData.level_3}°C (${apiData.color_3})`,
      S5: `${apiData.level_4}°C (${apiData.color_4})`,
      S6: `${apiData.level_5}°C (${apiData.color_5})`,
      S7: `${apiData.level_6}°C (${apiData.color_6})`,
      S8: `${apiData.level_7}°C (${apiData.color_7})`
    },
    maxTemp: `${maxTemp}°C`,
    siloColor: apiData.silo_color,
    timestamp: apiData.timestamp
  });
  
  return {
    siloNumber: apiData.silo_number,
    sensors,
    sensorColors,
    siloColor: apiData.silo_color,
    maxTemp,
    timestamp: new Date(apiData.timestamp),
    isLoaded: true
  };
};

// Fetch silo data from real API
export async function fetchSiloData(siloNumber: number): Promise<ProcessedSiloData> {
  // Check if already loading
  if (siloCache.isLoading(siloNumber)) {
    // Wait for existing request to complete
    return new Promise((resolve) => {
      const checkCache = () => {
        if (!siloCache.isLoading(siloNumber)) {
          resolve(siloCache.get(siloNumber) || siloCache.getDefaultSiloData(siloNumber));
        } else {
          setTimeout(checkCache, 100);
        }
      };
      checkCache();
    });
  }

  // Return cached data if available
  if (siloCache.has(siloNumber)) {
    return siloCache.get(siloNumber)!;
  }

  // Set loading state
  siloCache.setLoading(siloNumber, true);

  try {
    const url = `${API_BASE_URL}${API_ENDPOINT}?silo_number=${siloNumber}`;
    // Fetching silo data from API (logging removed for performance)

    // Add timestamp to prevent caching and avoid CORS preflight
    const timestamp = new Date().getTime();
    const urlWithTimestamp = `${url}&_t=${timestamp}`;
    
    const response = await fetch(urlWithTimestamp, {
      // Add timeout to prevent hanging requests
      signal: AbortSignal.timeout(10000) // 10 second timeout
    });

    if (!response.ok) {
      throw new Error(`API request failed: ${response.status} ${response.statusText}`);
    }

    const apiData: RealSiloApiResponse[] = await response.json();
    
    if (!apiData || apiData.length === 0) {
      // API returned empty array - silo is disconnected
      console.log(`🔌 [DISCONNECTED SILO] Silo ${siloNumber} returned empty array - setting disconnected gray color`);
      
      const disconnectedData: ProcessedSiloData = {
        siloNumber,
        sensors: [0, 0, 0, 0, 0, 0, 0, 0],  // All sensors zero
        sensorColors: Array(8).fill('#9ca3af'),  // All sensors gray (disconnected)
        siloColor: '#9ca3af',  // Disconnected gray color
        maxTemp: 0,
        timestamp: new Date(),
        isLoaded: true  // Mark as loaded but disconnected
      };
      
      // Cache the disconnected data
      siloCache.set(siloNumber, disconnectedData);
      
      return disconnectedData;
    }

    // Process the first (and should be only) result
    const processedData = processApiResponse(apiData[0]);
    
    // Cache the processed data
    siloCache.set(siloNumber, processedData);
    
    // Successfully fetched silo data (logging removed for performance)
    return processedData;

  } catch (error) {
    console.error(`Failed to fetch silo ${siloNumber} data:`, error);
    
    // Clear loading state
    siloCache.setLoading(siloNumber, false);
    
    // Return default wheat-colored data on error
    const defaultData = siloCache.getDefaultSiloData(siloNumber);
    siloCache.set(siloNumber, defaultData);
    
    return defaultData;
  }
}

// Fetch multiple silos data in parallel
export async function fetchMultipleSilosData(siloNumbers: number[]): Promise<ProcessedSiloData[]> {
  const promises = siloNumbers.map(siloNumber => fetchSiloData(siloNumber));
  return Promise.all(promises);
}

// Get silo data (from cache or default)
export function getSiloData(siloNumber: number): ProcessedSiloData {
  return siloCache.get(siloNumber) || siloCache.getDefaultSiloData(siloNumber);
}

// Check if silo data is loaded from API
export function isSiloDataLoaded(siloNumber: number): boolean {
  const data = siloCache.get(siloNumber);
  return data?.isLoaded || false;
}

// Get all loaded silo numbers
export function getLoadedSiloNumbers(): number[] {
  return siloCache.getCachedSiloNumbers().filter(siloNumber => 
    isSiloDataLoaded(siloNumber)
  );
}

// Clear specific silo from cache (including persistent storage)
export function clearSiloCache(siloNumber: number): void {
  siloCache.clearSilo(siloNumber);
}

// Clear all cached silo data (including persistent storage)
export function clearSiloDataCache(): void {
  siloCache.clear();
}

// Clear only persistent storage (keep in-memory cache for current session)
export const clearPersistentSiloCache = (): void => {
  try {
    localStorage.removeItem(SILO_CACHE_STORAGE_KEY);
    console.log('Cleared persistent silo cache storage');
  } catch (error) {
    console.warn('Failed to clear persistent silo cache:', error);
  }
}

// Convert hex color to internal temperature color type
export function convertApiColorToTemperatureColor(hexColor: string): TemperatureColor {
  // Convert API hex colors to internal color system
  const color = hexColor.toLowerCase();
  
  console.log(`🎨 [COLOR CONVERSION] Converting API color: ${hexColor} → ${color}`);
  
  // Gray colors (disconnected sensors) - keep as gray for disconnected silos
  if (color === '#9ca3af' || color.startsWith('#9ca') || color.startsWith('#6b7280') || 
      color.startsWith('#8c94') || color === '#8c9494' || color.startsWith('#8c')) {
    console.log(`🎨 [COLOR CONVERSION] Matched GRAY pattern for ${color} - keeping as GRAY (disconnected)`);
    return 'gray';
  }
  
  // Green colors (normal temperature range)
  if (color.startsWith('#46d4') || color.startsWith('#4') || color === '#00ff00' || 
      color === '#44ff44' || color.startsWith('#46') || color.startsWith('#22c55e')) {
    console.log(`🎨 [COLOR CONVERSION] Matched GREEN pattern for ${color}`);
    return 'green';
  }
  
  // Yellow colors (warning temperature range)
  if (color.startsWith('#c7c1') || color === '#c7c150' || color.startsWith('#eab308') ||
      color.startsWith('#f59e0b') || (color.startsWith('#ff') && color.includes('c'))) {
    console.log(`🎨 [COLOR CONVERSION] Matched YELLOW pattern for ${color}`);
    return 'yellow';
  }
  
  // Red colors (critical temperatures)
  if (color.startsWith('#ff') || color.startsWith('#f') || color === '#ff0000' || 
      color === '#ff4444' || color.startsWith('#d1') || color.startsWith('#d14141') ||
      color.startsWith('#ef4444') || color.startsWith('#dc2626')) {
    console.log(`🎨 [COLOR CONVERSION] Matched RED pattern for ${color}`);
    return 'pink';
  }
  
  // Default to gray for unknown colors (disconnected/unknown state)
  console.log(`🎨 [COLOR CONVERSION] Unknown color ${color}, defaulting to GRAY (disconnected)`);
  return 'gray';
}

// Retry mechanism for failed API calls
export async function fetchSiloDataWithRetry(
  siloNumber: number, 
  maxRetries: number = 3, 
  delayMs: number = 1000
): Promise<ProcessedSiloData> {
  let lastError: Error | null = null;
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      return await fetchSiloData(siloNumber);
    } catch (error) {
      lastError = error as Error;
      console.warn(`Attempt ${attempt}/${maxRetries} failed for silo ${siloNumber}:`, error);
      
      if (attempt < maxRetries) {
        // Wait before retry with exponential backoff
        const delay = delayMs * Math.pow(2, attempt - 1);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
  }
  
  console.error(`All ${maxRetries} attempts failed for silo ${siloNumber}:`, lastError);
  
  // Return default data after all retries failed
  const defaultData = siloCache.getDefaultSiloData(siloNumber);
  siloCache.set(siloNumber, defaultData);
  return defaultData;
}

// Export cache instance for testing/debugging
export { siloCache };
